# NoTrO Voice Assistant (offline, no VPN)

Jarvis-style offline assistant. Hold **Volume Up for 3 s** → it listens once for 10 s.
Say "NoTrO" (it answers "Sir Mr.NoTrO"), then your command — or the whole sentence at once.

## Build (GitHub, no VPN needed on your phone)
1. Create a GitHub repo, upload the *contents* of this folder (including the hidden `.github` folder; if it won't upload, create `.github/workflows/build.yml` manually in the GitHub web editor and paste the file).
2. Actions tab → "Build APK" → Run workflow. The runner downloads the Vosk English model itself.
3. Download artifact **NoTrO-apk**, unzip, install `app-debug.apk`.

## First run
- Allow mic, camera, phone, contacts, notifications.
- Tap "Enable volume trigger" → Accessibility → NoTrO → On.
- Tap "Allow display over other apps" (so calls/apps open from background).

## Commands
who am i · call X · flashlight on/off · selfie · screenshot (saved to Pictures/NoTrO) · lock screen · open app · search · time · date · battery · volume up/down · go home/back/recents
