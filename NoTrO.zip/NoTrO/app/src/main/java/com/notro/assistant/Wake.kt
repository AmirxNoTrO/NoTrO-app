package com.notro.assistant

/** Fuzzy helpers: the offline model often hears "NoTrO" as "nitro", "no tro", "know trow"... */
object Fuzzy {
    fun lev(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    /** 0.0 .. 1.0 */
    fun similarity(a: String, b: String): Double {
        val x = a.lowercase().replace(" ", "")
        val y = b.lowercase().replace(" ", "")
        if (x.isEmpty() || y.isEmpty()) return 0.0
        if (x == y) return 1.0
        if ((x.contains(y) || y.contains(x)) && minOf(x.length, y.length) >= 3) return 0.9
        return 1.0 - lev(x, y).toDouble() / maxOf(x.length, y.length)
    }
}

object Wake {
    private val known = setOf(
        "notro", "nitro", "nutro", "notrow", "nautro", "natro", "notrue", "nothro",
        "nothrow", "knowtro", "notroh", "nowtro", "notra", "nitra", "nutra", "notero"
    )

    private fun isWake(w: String): Boolean =
        w in known || (w.length in 4..6 && Fuzzy.lev(w, "notro") <= 1)

    /** Returns (wake word heard, the rest of the sentence without the wake word). */
    fun split(text: String): Pair<Boolean, String> {
        val words = text.split(" ").filter { it.isNotBlank() }
        val keep = ArrayList<String>()
        var heard = false
        var i = 0
        while (i < words.size) {
            if (isWake(words[i])) {
                heard = true; i += 1
            } else if (i + 1 < words.size && isWake(words[i] + words[i + 1])) {
                heard = true; i += 2
            } else {
                keep.add(words[i]); i += 1
            }
        }
        return Pair(heard, keep.joinToString(" "))
    }
}
