package com.notro.assistant

import android.accessibilityservice.AccessibilityService
import android.content.ContentValues
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Display
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Does three jobs: (1) watches the Volume Up key and starts listening after a 3 second hold,
 * (2) takes screenshots, (3) performs home / back / recents / lock-screen.
 */
class NotroAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val fire = Runnable { VoiceService.trigger(this) }

    override fun onServiceConnected() {
        inst = this
        super.onServiceConnected()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_UP) return false
        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.repeatCount == 0) {
                    handler.removeCallbacks(fire)
                    handler.postDelayed(fire, HOLD_MS)
                    return false          // first press still changes the volume once, as usual
                }
                return true               // swallow auto-repeat so holding does not ramp the volume
            }
            KeyEvent.ACTION_UP -> {
                handler.removeCallbacks(fire)
                return false
            }
        }
        return false
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(fire)
        if (inst === this) inst = null
        super.onDestroy()
    }

    fun global(action: Int) { performGlobalAction(action) }

    /** Takes a screenshot and saves it to Pictures/NoTrO. Needs Android 11+. */
    fun shot(done: (Boolean) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { done(false); return }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                var ok = false
                try {
                    val hb = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                    val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    if (bmp != null) {
                        val v = ContentValues()
                        v.put(MediaStore.Images.Media.DISPLAY_NAME, "NoTrO_" + System.currentTimeMillis() + ".png")
                        v.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NoTrO")
                        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
                        if (uri != null) {
                            val os = contentResolver.openOutputStream(uri)
                            if (os != null) {
                                bmp.compress(Bitmap.CompressFormat.PNG, 100, os)
                                os.close()
                                ok = true
                            }
                        }
                    }
                } catch (e: Exception) {
                    ok = false
                }
                done(ok)
            }

            override fun onFailure(errorCode: Int) { done(false) }
        })
    }

    companion object {
        const val HOLD_MS = 3000L
        const val HOME = GLOBAL_ACTION_HOME
        const val BACK = GLOBAL_ACTION_BACK
        const val RECENTS = GLOBAL_ACTION_RECENTS
        const val LOCK = 8 // GLOBAL_ACTION_LOCK_SCREEN (Android 9+)
        @Volatile var inst: NotroAccessibilityService? = null
    }
}
