package com.notro.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Deep, slow "Jarvis" voice. Works offline when the phone has any TTS voice installed; always shows a toast too. */
class TtsManager(private val ctx: Context) : TextToSpeech.OnInitListener {
    private val main = Handler(Looper.getMainLooper())
    private val tts = TextToSpeech(ctx, this)
    @Volatile private var ready = false
    private val callbacks = ConcurrentHashMap<String, () -> Unit>()

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val r = tts.setLanguage(Locale.US)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale.getDefault())
        }
        tts.setPitch(0.6f)
        tts.setSpeechRate(0.92f)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { finish(utteranceId) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { finish(utteranceId) }
        })
        ready = true
    }

    private fun finish(id: String?) {
        val cb = if (id != null) callbacks.remove(id) else null
        if (cb != null) main.post { cb() }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        main.post { Toast.makeText(ctx, text, Toast.LENGTH_SHORT).show() }
        if (!ready) {
            if (onDone != null) main.postDelayed({ onDone() }, 700)
            return
        }
        val id = "n" + System.nanoTime()
        if (onDone != null) callbacks[id] = onDone
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun shutdown() {
        try { tts.stop(); tts.shutdown() } catch (e: Exception) {}
    }
}
