package com.notro.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var tvStatus: TextView
    private lateinit var tvVolume: TextView
    private lateinit var tvOverlay: TextView
    private lateinit var ring: View
    private lateinit var orb: TextView
    private var pulse: ObjectAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvStatus = findViewById(R.id.tvStatus)
        tvVolume = findViewById(R.id.tvVolume)
        tvOverlay = findViewById(R.id.tvOverlay)
        ring = findViewById(R.id.ring)
        orb = findViewById(R.id.orb)

        orb.setOnClickListener { VoiceService.trigger(this) }
        findViewById<Button>(R.id.btnAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        val wanted = ArrayList<String>()
        wanted.add(Manifest.permission.RECORD_AUDIO)
        wanted.add(Manifest.permission.CAMERA)
        wanted.add(Manifest.permission.CALL_PHONE)
        wanted.add(Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = wanted.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        else ensureService()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        ensureService()
    }

    private fun ensureService() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            tvStatus.text = "Microphone permission is needed"
            return
        }
        if (VoiceService.instance == null) VoiceService.start(this)
    }

    override fun onResume() {
        super.onResume()
        VoiceService.listener = { text, listening -> runOnUiThread { show(text, listening) } }
        show(VoiceService.status, VoiceService.isListening)
        val acc = NotroAccessibilityService.inst != null
        tvVolume.text = if (acc) "Volume trigger is ON: hold Volume Up for 3 seconds" else "Volume trigger is OFF: enable the NoTrO accessibility service"
        val ov = Settings.canDrawOverlays(this)
        tvOverlay.text = if (ov) "Opening apps from the background is allowed" else "Allow \"display over other apps\" so calls and apps can open from the background"
        ensureService()
    }

    override fun onPause() {
        VoiceService.listener = null
        super.onPause()
    }

    private fun show(text: String, listening: Boolean) {
        tvStatus.text = text
        orb.text = if (listening) "LISTENING" else "TAP"
        if (listening) {
            if (pulse == null) {
                pulse = ObjectAnimator.ofPropertyValuesHolder(
                    ring,
                    PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.45f),
                    PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.45f),
                    PropertyValuesHolder.ofFloat(View.ALPHA, 0.8f, 0f)
                ).apply {
                    duration = 1100
                    repeatCount = ObjectAnimator.INFINITE
                    start()
                }
            }
            ring.visibility = View.VISIBLE
        } else {
            pulse?.cancel()
            pulse = null
            ring.scaleX = 1f
            ring.scaleY = 1f
            ring.alpha = 0f
        }
    }
}
