package com.notro.assistant

import android.Manifest
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.ContactsContract
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Understands the English commands and runs them. Everything here works without internet. */
class CommandHandler(private val c: Context, private val tts: TtsManager) {
    private val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    // Activities started from the accessibility service are allowed from the background more often.
    private fun go(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val ctx: Context = NotroAccessibilityService.inst ?: c
        ctx.startActivity(i)
    }

    fun handle(raw: String) {
        val x = raw.lowercase().replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
        val t = x.removePrefix("please ").removePrefix("can you ").removePrefix("could you ").trim()
        try {
            when {
                t.isEmpty() -> tts.speak("Yes sir?")
                t == "stop" || t == "cancel" || t.contains("never mind") -> tts.speak("Okay")
                t.contains("who am i") -> tts.speak("You are Sir Mr.NoTrO")
                t.startsWith("call") -> call(t.removePrefix("call").trim())
                t.contains("flashlight") || t.contains("flash light") || t.contains("torch") -> torch(!(t.contains(" off") || t.contains("disable")))
                t.contains("selfie") -> selfie()
                t.contains("screenshot") || t.contains("screen shot") -> screenshot()
                t.contains("look screen") || t.contains("lock screen") || t.contains("lock the screen") || t.contains("lock phone") -> lock()
                t.contains("lens") -> lens()
                t.startsWith("open") || t.startsWith("launch") -> openApp(t.substringAfter(" ", "").trim())
                t.startsWith("search") || t.startsWith("google") -> search(t.substringAfter(" ", "").trim())
                t.contains("time") && (t.contains("what") || t.contains("tell")) -> tts.speak("It is " + SimpleDateFormat("h mm a", Locale.US).format(Date()))
                t.contains("date") || t.contains("today") -> tts.speak("Today is " + SimpleDateFormat("EEEE MMMM d", Locale.US).format(Date()))
                t.contains("battery") -> battery()
                t.contains("volume up") || t.contains("louder") -> volume(true)
                t.contains("volume down") || t.contains("quieter") || t.contains("lower the volume") -> volume(false)
                t.contains("go home") || t == "home" -> system(NotroAccessibilityService.HOME, "Home")
                t.contains("go back") || t == "back" -> system(NotroAccessibilityService.BACK, "Back")
                t.contains("recent") -> system(NotroAccessibilityService.RECENTS, "Recent apps")
                else -> tts.speak("Sorry sir, I did not get that")
            }
        } catch (e: SecurityException) {
            tts.speak("Permission is missing")
        } catch (e: Exception) {
            tts.speak("Something went wrong")
        }
    }

    private fun call(arg: String) {
        val who = arg.removePrefix("to ").trim()
        if (who.isEmpty()) { tts.speak("Who should I call?"); return }
        val digits = spokenDigits(who)
        val number = if (digits.length >= 3) digits else findContact(who)
        if (number == null) { tts.speak("Contact not found"); return }
        tts.speak("Calling $who")
        val granted = ContextCompat.checkSelfPermission(c, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        go(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
    }

    private fun findContact(name: String): String? {
        if (ContextCompat.checkSelfPermission(c, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            tts.speak("I need the contacts permission")
            return null
        }
        var best: String? = null
        var bestScore = 0.0
        val cur = c.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )
        if (cur != null) {
            while (cur.moveToNext()) {
                val n = cur.getString(0)
                val num = cur.getString(1)
                if (n == null || num == null) continue
                val s = Fuzzy.similarity(n, name)
                if (s > bestScore) { bestScore = s; best = num }
            }
            cur.close()
        }
        return if (bestScore >= 0.6) best else null
    }

    private fun spokenDigits(s: String): String {
        val map = mapOf(
            "zero" to "0", "oh" to "0", "one" to "1", "two" to "2", "to" to "2", "too" to "2", "three" to "3",
            "four" to "4", "for" to "4", "five" to "5", "six" to "6", "seven" to "7", "eight" to "8", "nine" to "9"
        )
        val sb = StringBuilder()
        for (w in s.split(" ")) {
            if (w.isEmpty()) continue
            if (w.all { it.isDigit() }) sb.append(w)
            else { val d = map[w]; if (d != null) sb.append(d) else return "" }
        }
        return sb.toString()
    }

    private fun torchId(): String? = cm.cameraIdList.firstOrNull {
        cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
    }

    private fun torch(on: Boolean) {
        val id = torchId()
        if (id == null) { tts.speak("No flashlight found"); return }
        cm.setTorchMode(id, on)
        tts.speak(if (on) "Flashlight on" else "Flashlight off")
    }

    private fun selfie() {
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        i.putExtra("android.intent.extras.CAMERA_FACING", 1)
        i.putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
        tts.speak("Taking a selfie")
        go(i)
    }

    private fun screenshot() {
        val svc = NotroAccessibilityService.inst
        if (svc == null) { tts.speak("Turn on the NoTrO accessibility service first"); return }
        svc.shot { ok -> tts.speak(if (ok) "Screenshot saved" else "Screenshot failed") }
    }

    private fun lock() {
        val svc = NotroAccessibilityService.inst
        if (svc == null) { tts.speak("Turn on the NoTrO accessibility service first"); return }
        tts.speak("Locking the screen")
        svc.global(NotroAccessibilityService.LOCK)
    }

    private fun system(action: Int, say: String) {
        val svc = NotroAccessibilityService.inst
        if (svc == null) { tts.speak("Turn on the NoTrO accessibility service first"); return }
        tts.speak(say)
        svc.global(action)
    }

    private fun lens() {
        try {
            val i = Intent("com.google.android.googlequicksearchbox.GOOGLE_SEARCH")
            i.putExtra("gsp", "lens")
            go(i)
        } catch (e: Exception) {
            tts.speak("Lens not found")
        }
    }

    private fun search(q: String) {
        if (q.isEmpty()) { tts.speak("What should I search?"); return }
        tts.speak("Searching $q")
        try {
            go(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
        } catch (e: ActivityNotFoundException) {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        }
    }

    private fun openApp(name: String) {
        val q = name.replace(" ", "")
        if (q.isEmpty()) { tts.speak("Which app?"); return }
        val pm = c.packageManager
        val apps: List<ResolveInfo> = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        var best: ResolveInfo? = null
        var bestScore = 0.0
        for (a in apps) {
            val s = Fuzzy.similarity(a.loadLabel(pm).toString(), q)
            if (s > bestScore) { bestScore = s; best = a }
        }
        val b = best
        if (b == null || bestScore < 0.6) { tts.speak("App not found"); return }
        val launch = pm.getLaunchIntentForPackage(b.activityInfo.packageName)
        if (launch == null) { tts.speak("App not found"); return }
        tts.speak("Opening $name")
        go(launch)
    }

    private fun battery() {
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val p = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        tts.speak("Battery is at $p percent")
    }

    private fun volume(up: Boolean) {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        repeat(3) {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        }
        tts.speak(if (up) "Volume up" else "Volume down")
    }
}
