package com.notro.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService

/**
 * Stays alive in the background with the offline voice model loaded (no internet, no VPN).
 * It only uses the microphone for 10 seconds after you trigger it (Volume Up held 3 s, the orb, or the notification button).
 * Flow: trigger -> say "NoTrO" -> "Sir Mr.NoTrO" -> say the command (or say it in the same sentence).
 */
class VoiceService : Service(), RecognitionListener {
    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var ss: SpeechService? = null
    private var tts: TtsManager? = null
    private var cmd: CommandHandler? = null
    private var tone: ToneGenerator? = null
    private var active = false      // a listening session is in progress
    private var awaiting = false    // wake word already heard, waiting for the command

    override fun onCreate() {
        super.onCreate()
        instance = this
        val n = notif("Loading voice model...")
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TtsManager(this)
        cmd = CommandHandler(this, tts!!)
        try { tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80) } catch (e: Exception) {}
        setStatus("Loading voice model...", false)
        StorageService.unpack(this, MODEL_DIR, "model",
            { m -> main.post { onModel(m) } },
            { e -> main.post { onModelError(e.message) } })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_LISTEN) activate()
        return START_STICKY
    }

    private fun onModel(m: Model) {
        model = m
        setStatus("Ready. Hold Volume Up for 3 seconds", false)
        if (pending) { pending = false; activate() }
    }

    private fun onModelError(msg: String?) {
        setStatus("Voice model missing. Rebuild the app with the model", false)
        tts?.speak("Voice model is missing")
    }

    /** Starts one listening session. */
    fun activate() {
        main.post {
            if (model == null) { pending = true; setStatus("Loading voice model...", false); return@post }
            if (active) return@post
            beep(true)
            startListen(false)
        }
    }

    private fun startListen(waitForCommand: Boolean) {
        stopRecognizer()
        val m = model ?: return
        try {
            val r = Recognizer(m, 16000f)
            val s = SpeechService(r, 16000f)
            ss = s
            awaiting = waitForCommand
            active = true
            s.startListening(this, LISTEN_MS)
            setStatus(if (waitForCommand) "Say your command..." else "Listening... say NoTrO", true)
        } catch (e: Exception) {
            active = false
            setStatus("Microphone error", false)
            tts?.speak("Microphone error")
        }
    }

    private fun stopRecognizer() {
        val s = ss
        ss = null
        if (s != null) {
            try { s.stop() } catch (e: Exception) {}
            try { s.shutdown() } catch (e: Exception) {}
        }
    }

    private fun finishSession(status: String) {
        active = false
        awaiting = false
        stopRecognizer()
        setStatus(status, false)
    }

    override fun onResult(hypothesis: String?) {
        if (!active || ss == null || hypothesis == null) return
        val text = try { JSONObject(hypothesis).optString("text", "") } catch (e: Exception) { "" }.lowercase().trim()
        if (text.isEmpty()) return
        val (heard, rest) = Wake.split(text)
        if (awaiting) {
            finishSession("Ready. Hold Volume Up for 3 seconds")
            beep(false)
            cmd?.handle(if (heard) rest else text)
            return
        }
        if (!heard) { setStatus("Heard: \"$text\". Say NoTrO first", true); return }
        if (rest.isBlank()) {
            // only the name: answer, then listen once more for the command
            stopRecognizer()
            setStatus("Sir Mr.NoTrO", true)
            tts?.speak("Sir Mr.NoTrO") { if (active) startListen(true) }
        } else {
            finishSession("Ready. Hold Volume Up for 3 seconds")
            beep(false)
            cmd?.handle(rest)
        }
    }

    // Stale results from a recognizer that was just stopped are ignored on purpose.
    override fun onFinalResult(hypothesis: String?) {}
    override fun onPartialResult(hypothesis: String?) {}

    override fun onError(exception: Exception?) {
        finishSession("Error. Try again")
        tts?.speak("Error")
    }

    override fun onTimeout() {
        if (!active) return
        finishSession("Ready. Hold Volume Up for 3 seconds")
        beep(false)
    }

    private fun beep(start: Boolean) {
        try { tone?.startTone(if (start) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP2, 150) } catch (e: Exception) {}
    }

    private fun setStatus(s: String, listening: Boolean) {
        status = s
        isListening = listening
        main.post {
            listener?.invoke(s, listening)
            try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, notif(s)) } catch (e: Exception) {}
        }
    }

    private fun notif(text: String): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "NoTrO", NotificationManager.IMPORTANCE_LOW))
        }
        val listenPi = PendingIntent.getService(this, 1, Intent(this, VoiceService::class.java).setAction(ACTION_LISTEN),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val openPi = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("NoTrO")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openPi)
            .addAction(0, "Listen", listenPi)
            .setOngoing(true)
            .build()
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onDestroy() {
        active = false
        stopRecognizer()
        try { model?.close() } catch (e: Exception) {}
        tts?.shutdown()
        tone?.release()
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        const val MODEL_DIR = "vosk-model-small-en-us-0.15"
        const val CHANNEL = "notro"
        const val ACTION_LISTEN = "com.notro.assistant.LISTEN"
        const val LISTEN_MS = 10000

        @Volatile var instance: VoiceService? = null
        @Volatile var status: String = "Starting..."
        @Volatile var isListening: Boolean = false
        @Volatile var pending: Boolean = false
        var listener: ((String, Boolean) -> Unit)? = null

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, VoiceService::class.java))
        }

        /** Called by the accessibility service (Volume Up held 3 s) and by the orb. */
        fun trigger(ctx: Context) {
            val s = instance
            if (s != null) { s.activate(); return }
            pending = true
            try { start(ctx) } catch (e: Exception) {}
        }
    }
}
